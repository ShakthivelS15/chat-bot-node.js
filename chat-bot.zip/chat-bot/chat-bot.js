import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: "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",
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post("/chat", async (req, res) => {
  const userMessage = req.body.message;
  if (!userMessage) {
    return res.status(400).json({ error: "Message is required" });
  }
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "user", content: userMessage },
      ],
    });
    const reply = completion.choices[0].message.content;
    res.json({ reply });
  } catch (error) {
    res.status(500).json({ error: error.message || "OpenAI error" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
